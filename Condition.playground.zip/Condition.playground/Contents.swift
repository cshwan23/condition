
// <3강 조건문>
// 흐름 제어 구문 : 코드의 흐름을 제어하는 구문은 조건문, 반복문이 있다.

/*
if <#condition#> {           if(만약 condition(true/false를 나타내는 조건문)이 참일 때
    <#code#>                 {code}{이 코드가 실행된다.}
} */

let dust = 155

if dust <= 30 {                       // 비교 연산자
    print("아 공기 상쾌하다~~")
}
    // if문은 조건문을 여러개로 추가할 수 있는데, 이 때 else if를 쓴다

else if dust > 30 && dust <= 50 {     // 논리 연산자 좌우의 조건문이 모두 참일 때 참
print("뭐 이 정도면 나쁘지 않군")
}

else if dust > 50 && dust <= 100 {
    print("아 안좋아~")
}
else {
    print("헉 최악이다!ㅜ")
}
//switch문  => 실수 많이 하는 것, default 값 꼭 써줘야 된다. 안 쓰면 에러 나옴.

let wether = "비"
switch wether {
case "맑음":
    print("☀️")
case "흐림":
    print("☁️")
case "비", "장마", "소나기":
    print("☔️")
case "눈":
    print("🌨")
default:
    print("🌤")
}


